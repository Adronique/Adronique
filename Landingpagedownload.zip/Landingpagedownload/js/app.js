// Variables
const Responsivenav = document.getElementById('navbar__list');
const sections = document.querySelectorAll('section');

// Building Navigation
const createNav = () => {
    let topBar = '';
    sections.forEach(section => {
        const sectionID = section.id;
        const sectionDataNav = section.dataset.nav;
        topBar += `<li><a class="header__links" href="#${sectionID}">${sectionDataNav}</a></li>`;
    });
    Responsivenav.innerHTML = topBar;
};

createNav();

// Adding active "class" to links
const figureOffset = (section) => {
    return Math.floor(section.getBoundingClientRect().top);
};

const removeActiveClass = (section) => {
    section.classList.remove('your-active-class');
    document.body.classList.remove('dark-pink-bg');
};

const addActiveClass = (conditional, section) => {
    if (conditional) {
        section.classList.add('your-active-class');
        document.body.classList.add('dark-pink-bg');
    }
};

const sectionHighlight = () => {
    sections.forEach(section => {
        const offset = figureOffset(section);
        const viewport = () => offset < 100 && offset >= -100;
        removeActiveClass(section);
        addActiveClass(viewport(), section);
    });
};

window.addEventListener('scroll', sectionHighlight);

// Scroll to anchor ID using ScrollTo event
const scrollToSection = (element) => {
    window.scrollTo({
        behavior: 'smooth',
        top: element.offsetTop - 100
    });
};

const hyperlinks = document.querySelectorAll('.navbar__menu a');
hyperlinks.forEach(hyperlink => {
    hyperlink.addEventListener('click', (event) => {
        event.preventDefault();
        const targetSectionID = hyperlink.getAttribute('href').slice(1);
        const targetSection = document.getElementById(targetSectionID);
        if (targetSection) {
            scrollToSection(targetSection);
        }
    });
});
